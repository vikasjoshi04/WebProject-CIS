-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Aug 28, 2019 at 05:36 PM
-- Server version: 5.7.27-0ubuntu0.16.04.1
-- PHP Version: 7.0.33-0ubuntu0.16.04.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bankingsystem`
--

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `id` int(100) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `age` int(100) DEFAULT NULL,
  `address` varchar(150) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `transactionDetails`
--

CREATE TABLE `transactionDetails` (
  `tran_id` int(11) NOT NULL,
  `User_id` int(11) DEFAULT NULL,
  `deposite_amt` float DEFAULT NULL,
  `withdrawl_amt` float DEFAULT NULL,
  `total_bal` float DEFAULT NULL,
  `tran_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `transactionDetails`
--

INSERT INTO `transactionDetails` (`tran_id`, `User_id`, `deposite_amt`, `withdrawl_amt`, `total_bal`, `tran_date`) VALUES
(3, 2, 10000, 0, 10000, '2019-08-01'),
(4, 1, 1000, 0, 34000, '2019-08-26'),
(5, 1, 0, 4000, 30000, '2019-08-26'),
(6, 1, 0, 5000, 25000, '2019-08-26'),
(7, 1, 5000, 0, 30000, '2019-08-26'),
(8, 4, 10000, 0, 18000, '2019-08-26'),
(9, 4, 0, 2000, 16000, '2019-08-26'),
(10, 1, 0, 10000, 40000, '2019-08-26'),
(11, 1, 5000, 0, 45000, '2019-08-26'),
(12, 6, 0, 1000, -1000, '2019-08-26'),
(13, 6, 5000, 0, 4000, '2019-08-26'),
(14, 1, 5000, 0, 50000, '2019-08-27'),
(15, 1, 5000, 0, 50000, '2019-08-27'),
(16, 1, 5000, 0, 50000, '2019-08-27'),
(17, 1, 1000, 0, 51000, '2019-08-27'),
(18, 1, 4000, 0, 55000, '2019-08-27'),
(19, 1, 5000, 0, 60000, '2019-08-27'),
(20, 1, 1000, 0, 61000, '2019-08-27'),
(21, 1, 4000, 0, 65000, '2019-08-27'),
(22, 1, 0, 15000, 50000, '2019-08-27'),
(23, 1, 10000, 0, 60000, '2019-08-27'),
(24, 1, 0, 4000, 56000, '2019-08-27'),
(25, 1, 0, 6000, 50000, '2019-08-27'),
(26, 1, 0, 10000, 40000, '2019-08-28'),
(27, 1, 5000, 0, 45000, '2019-08-28'),
(28, 1, 0, 5000, 40000, '2019-08-28'),
(29, 1, 5000, 0, 45000, '2019-08-28'),
(30, 1, 0, 5000, 40000, '2019-08-28'),
(31, 1, 10000, 0, 50000, '2019-08-28'),
(32, 1, 0, 5000, 45000, '2019-08-28'),
(33, 7, 10000, 0, 30000, '2019-08-28');

-- --------------------------------------------------------

--
-- Table structure for table `userDetails`
--

CREATE TABLE `userDetails` (
  `userId` int(11) NOT NULL,
  `username` varchar(45) DEFAULT NULL,
  `accountNo` bigint(11) DEFAULT NULL,
  `Balance` float DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `password` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `userDetails`
--

INSERT INTO `userDetails` (`userId`, `username`, `accountNo`, `Balance`, `email`, `password`) VALUES
(1, 'Vikas Joshi', 815485176, 45000, 'vikasjoshi19396@gmail.com', '1234'),
(2, 'Akash Rathore', 971320309, 55555, 'akash@gmail.com', 'akash@123'),
(3, 'Mahendra Panchal', 435423642, 7000, 'mahendra@gmail.com', 'mahendra@123'),
(4, 'Ravindra Kumar', 987654327, 16000, 'ravindra@gmail.com', 'rk@123'),
(5, 'Dipesh Birla', 764096174, 10000, 'dipesh@gmail.com', 'dipesh@123'),
(6, 'Surjeet Singh', 287690940, 4000, 'surjeet@gmail.com', 'surjeet@123'),
(7, 'Ashish Patel', 865377166, 30000, 'ashish@gmail.com', 'ashish@123');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `transactionDetails`
--
ALTER TABLE `transactionDetails`
  ADD PRIMARY KEY (`tran_id`),
  ADD KEY `User_id` (`User_id`);

--
-- Indexes for table `userDetails`
--
ALTER TABLE `userDetails`
  ADD PRIMARY KEY (`userId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `transactionDetails`
--
ALTER TABLE `transactionDetails`
  MODIFY `tran_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;
--
-- AUTO_INCREMENT for table `userDetails`
--
ALTER TABLE `userDetails`
  MODIFY `userId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `transactionDetails`
--
ALTER TABLE `transactionDetails`
  ADD CONSTRAINT `userConst` FOREIGN KEY (`User_id`) REFERENCES `userDetails` (`userId`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
