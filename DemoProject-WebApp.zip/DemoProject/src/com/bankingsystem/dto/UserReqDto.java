package com.bankingsystem.dto;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.bankingsystem.dao.UserReg;
import com.bankingsystem.db.DBConnection;

public class UserReqDto {
	Connection con = null;
	PreparedStatement pstm = null;

	public String addUser(UserReg us) {
		String username = us.getUsername();
		String email = us.getEmail();
		String pass = us.getPassword();
		int accountNo = us.getAccountNo();

		try {

			con = DBConnection.getConnection();
			pstm = con.prepareStatement("insert into userDetails(username,accountNo,email,password) values(?,?,?,?)");
			pstm.setString(1, username);
			pstm.setInt(2, accountNo);
			pstm.setString(3, email);
			pstm.setString(4, pass);

			int i = pstm.executeUpdate();
			if (i > 0) {
				System.out.println("User Registered SuccessFully");
				return "true";
			} else {
				System.out.println("User Registration Failed");
				return "false";
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				pstm.close();
				con.close();

			} catch (Exception e) {
				e.printStackTrace();
			}

		}

		return "false";
	}

	public String checkUser(UserReg us) {

		String email = us.getEmail();
		String pass = us.getPassword();

		try {

			con = DBConnection.getConnection();
			pstm = con.prepareStatement("select * from userDetails where email = ? and password = ?");
			pstm.setString(1, email);
			pstm.setString(2, pass);

			ResultSet rs = pstm.executeQuery();

			if (rs.next()) {
				System.out.println("User Login Success");
				return String.valueOf(rs.getInt("userId"));
			} else {
				System.out.println("User Login Failed");
				return "false";
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return "false";
	}

	public String updateUserBalance(UserReg user) {
		int id = Integer.parseInt(user.getUserId());
		float balance = user.getBalance();
		System.out.println("In Update Balance Dto");
		try {

			con = DBConnection.getConnection();
			pstm = con.prepareStatement("update userDetails set Balance = ? where userId = ?");
			pstm.setFloat(1, balance);
			pstm.setInt(2, id);

			int i = pstm.executeUpdate();

			if (i > 0) {
				System.out.println("User Balance Update Success");
				return "true";
			} else {
				System.out.println("User Balance Update Failed");
				return "false";
			}

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}

		return "false";
	}
}
