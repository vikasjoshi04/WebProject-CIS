package com.bankingsystem.dto;

import java.io.FileOutputStream;

import java.util.Date;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfPCell;
//import com.itextpdf.text.pdf.PdfPRow;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.bankingsystem.dao.UserTransaction;
import com.bankingsystem.db.DBConnection;

public class UserTransDto {
	Connection con = null;
	PreparedStatement pstm = null;

	public String addTransaction(UserTransaction user) {

		int userId = user.getUserId();
		float deposit = user.getDeposit();

		float withdraw = user.getWithdraw();
		float totalAmt = user.getTotal_amt();
		String date = user.getDate();

		try {

			con = DBConnection.getConnection();
			pstm = con.prepareStatement(
					"insert into transactionDetails(user_id,deposite_amt,withdrawl_amt,total_bal,tran_date) values(?,?,?,?,?)");
			pstm.setInt(1, userId);
			if (user.getDeposit() != 0.0f) {
				pstm.setFloat(2, deposit);
			} else {
				pstm.setFloat(2, 0);
			}
			if (user.getWithdraw() != 0.0f) {
				pstm.setFloat(3, withdraw);
			} else {
				pstm.setFloat(3, 0);
			}
			pstm.setFloat(4, totalAmt);
			pstm.setDate(5, java.sql.Date.valueOf(date));

			int i = pstm.executeUpdate();
			if (i > 0) {
				System.out.println("Transaction Details Added SuccessFully");
				return "true";
			} else {
				System.out.println("Transaction Details Failed");
				return "false";
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				pstm.close();
				con.close();

			} catch (Exception e) {
				e.printStackTrace();
			}

		}

		return "false";

	}

	public String generateTransPdf(UserTransaction user) {

		int userId = user.getUserId();
		String sdate = user.getDate();
		String edate = user.getEdate();

		try {

			con = DBConnection.getConnection();
			pstm = con.prepareStatement(
					"select * from transactionDetails where user_id= ? AND tran_date BETWEEN ? and ?");
			pstm.setInt(1, userId);
			pstm.setDate(2, java.sql.Date.valueOf(sdate));
			pstm.setDate(3, java.sql.Date.valueOf(edate));

			ResultSet rs = pstm.executeQuery();
			rs = pstm.executeQuery();

			Document document = new Document();
			try {
				 String FILE = "BankStatement.pdf";
				 //String FILE = "/home/cis/eclipse-workspace/DemoProject/PdfFiles/BankStatement.pdf";
				PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream(FILE));
				document.open();
				document.add(new Paragraph("Bank Statement",FontFactory.getFont(FontFactory.TIMES_BOLD,18,Font.BOLD,BaseColor.RED)));
				document.add(new Paragraph(new Date().toString()));
				document.add(new Paragraph("____________________________________________________________________________"));
				PdfPTable table = new PdfPTable(6); // 3 columns.
				table.setWidthPercentage(100); // Width 100%
				table.setSpacingBefore(10f); // Space before table
				table.setSpacingAfter(10f); // Space after table

				// Set Column widths
				float[] columnWidths = { 1f, 1f, 1f, 1f, 1f, 1f };
				table.setWidths(columnWidths);

				PdfPCell cell1 = new PdfPCell(new Paragraph("Transaction Id"));
				cell1.setBorderColor(BaseColor.BLUE);
				cell1.setPaddingLeft(10);
				cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);

				PdfPCell cell2 = new PdfPCell(new Paragraph("User Id"));
				cell2.setBorderColor(BaseColor.BLUE);
				cell2.setPaddingLeft(10);
				cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell2.setVerticalAlignment(Element.ALIGN_MIDDLE);

				PdfPCell cell3 = new PdfPCell(new Paragraph("Deposit Amount"));
				cell3.setBorderColor(BaseColor.BLUE);
				cell3.setPaddingLeft(10);
				cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell3.setVerticalAlignment(Element.ALIGN_MIDDLE);

				PdfPCell cell4 = new PdfPCell(new Paragraph("Withdrawl Amount"));
				cell4.setBorderColor(BaseColor.BLUE);
				cell4.setPaddingLeft(10);
				cell4.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell4.setVerticalAlignment(Element.ALIGN_MIDDLE);

				PdfPCell cell5 = new PdfPCell(new Paragraph("Transaction Date"));
				cell5.setBorderColor(BaseColor.BLUE);
				cell5.setPaddingLeft(10);
				cell5.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell5.setVerticalAlignment(Element.ALIGN_MIDDLE);

				PdfPCell cell6 = new PdfPCell(new Paragraph("Total Amount"));
				cell6.setBorderColor(BaseColor.BLUE);
				cell6.setPaddingLeft(10);
				cell6.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell6.setVerticalAlignment(Element.ALIGN_MIDDLE);

				table.addCell(cell1);
				table.addCell(cell2);
				table.addCell(cell3);
				table.addCell(cell4);
				table.addCell(cell5);
				table.addCell(cell6);

				if (rs.next()) {

					while (rs.next()) {

						table.addCell("" + rs.getInt("tran_id"));
						table.addCell("" + rs.getInt("user_id"));
						table.addCell("" + rs.getFloat("deposite_amt"));
						table.addCell("" + rs.getFloat("withdrawl_amt"));
						table.addCell("" + rs.getDate("tran_date"));
						table.addCell("" + rs.getFloat("total_bal"));

					}

					document.add(table);
					document.close();
					writer.close();

					return "true";
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				pstm.close();
				con.close();

			} catch (Exception e) {
				e.printStackTrace();
			}

		}

		return "false";
	}

}
