package com.bankingsystem.servlet;

import java.io.IOException;
import java.sql.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bankingsystem.dto.UserTransDto;

/**
 * Servlet implementation class UserTransactionPdf
 */
@WebServlet("/UserTransactionPdf")
public class UserTransactionPdf extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public UserTransactionPdf() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		/*
		 * // TODO Auto-generated method stub
		 * response.getWriter().append("Served at: ").append(request.getContextPath());
		 */
		int userId = Integer.parseInt(request.getParameter("userId"));
		String startDate = request.getParameter("startdate");
		String endDate = request.getParameter("enddate");

//		System.out.println(" "+startDate+" "+endDate);

		com.bankingsystem.dao.UserTransaction userTrans = new com.bankingsystem.dao.UserTransaction();

		userTrans.setUserId(userId);
		userTrans.setDate(startDate);
		userTrans.setEdate(endDate);

		UserTransDto userdto = new UserTransDto();
		String status = userdto.generateTransPdf(userTrans);

		response.sendRedirect("UserTransaction.jsp?status=" + status);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
