package com.bankingsystem.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bankingsystem.dao.UserReg;
import com.bankingsystem.dto.UserReqDto;
import java.util.Random;

/**
 * Servlet implementation class UserRegistration
 */
@WebServlet("/UserRegistration")
public class UserRegistration extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public UserRegistration() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		// response.getWriter().append("Served at: ").append(request.getContextPath());

		String username = request.getParameter("username");
		String email = request.getParameter("email");
		String password = request.getParameter("password");
		UserReg usr = new UserReg();
		Random rand = new Random();

		usr.setUsername(username);
		usr.setEmail(email);
		usr.setPassword(password);

		int rand_int1 = rand.nextInt(1000000000); // generating random account number
		usr.setAccountNo(rand_int1);

		UserReqDto add = new UserReqDto();

		String res = add.addUser(usr);
		response.sendRedirect("UserLogin.jsp?status=" + res);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
