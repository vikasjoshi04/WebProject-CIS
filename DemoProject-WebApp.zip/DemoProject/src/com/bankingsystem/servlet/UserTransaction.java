package com.bankingsystem.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bankingsystem.dao.UserReg;
import com.bankingsystem.dto.UserReqDto;
import com.bankingsystem.dto.UserTransDto;

import java.util.*;
import javax.mail.*;
import javax.mail.internet.*;

/**
 * Servlet implementation class UserTransaction
 */
@WebServlet("/UserTransaction")
public class UserTransaction extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public UserTransaction() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		/*
		 * // TODO Auto-generated method stub
		 * response.getWriter().append("Served at: ").append(request.getContextPath());
		 */
		System.out.println("User Transaction Servlet");
		int userId = Integer.parseInt(request.getParameter("userId"));
		float total_amt = Float.parseFloat(request.getParameter("balance"));

		com.bankingsystem.dao.UserTransaction userTrans = new com.bankingsystem.dao.UserTransaction();
		UserReqDto userBalUpdate = new UserReqDto();
		UserReg userdetail = new UserReg();
		UserTransDto userDto = new UserTransDto();

		long millis = System.currentTimeMillis();

		java.sql.Date date = new java.sql.Date(millis);
		System.out.println(date);

		if (!String.valueOf(request.getParameter("deposit")).equalsIgnoreCase("")) {
			System.out.println("if condition");
			float deposit = Float.parseFloat(request.getParameter("deposit"));

			total_amt += deposit;

			userTrans.setDeposit(deposit);
			userTrans.setUserId(userId);
			userTrans.setTotal_amt(total_amt);
			userTrans.setDate(String.valueOf(date));

			userdetail.setBalance(total_amt);
			userdetail.setUserId(String.valueOf(userId));

			String status = userBalUpdate.updateUserBalance(userdetail);

			if (!status.equalsIgnoreCase("false")) {
				String status1 = userDto.addTransaction(userTrans);
				if (status1.equalsIgnoreCase("true")) {

//					---------------------------------------------------

					// Creating a result for getting status that messsage is delivered or not!
					String result;
					// Get recipient's email-ID, message & subject-line from index.html page
					final String to = "vikasjoshi19396@gmail.com";
					final String subject = "Bank Transactions";
					final String msg = "Dear Customer Mr/Ms " + userId
							+ ". Your Account Balance Has Been Updated with a Deposit of " + total_amt + " Rs.";

					// Sender's email ID and password needs to be mentioned
					final String from = "abc@gmail.com";
					final String pass = "abc@123";

					// Defining the gmail host
					String host = "smtp.gmail.com";

					// Creating Properties object
					Properties props = new Properties();

					// Defining properties
					props.put("mail.smtp.host", host);
					props.put("mail.transport.protocol", "smtp");
					props.put("mail.smtp.auth", "true");
					props.put("mail.smtp.starttls.enable", "true");
					props.put("mail.user", from);
					props.put("mail.password", pass);
					props.put("mail.smtp.port", "465");
					props.put("mail.debug", "true");
					props.put("mail.smtp.socketFactory.port", "465");
					props.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
					props.put("mail.smtp.socketFactory.fallback", "false");

					// Authorized the Session object.
					Session mailSession = Session.getInstance(props, new javax.mail.Authenticator() {
						@Override
						protected PasswordAuthentication getPasswordAuthentication() {
							return new PasswordAuthentication(from, pass);
						}
					});

					try {
						// Create a default MimeMessage object.
						MimeMessage message = new MimeMessage(mailSession);
						// Set From: header field of the header.
						message.setFrom(new InternetAddress(from));
						// Set To: header field of the header.
						message.addRecipient(Message.RecipientType.TO, new InternetAddress(to));
						// Set Subject: header field
						message.setSubject(subject);
						// Now set the actual message
						message.setText(msg);
						// Send message
						Transport.send(message);
						result = "true";
					} catch (MessagingException mex) {
						mex.printStackTrace();
						result = "false";
					}

//					----------------------------------------------------

					response.sendRedirect("WelcomeUser.jsp?status=" + result);
				} else {
					response.sendRedirect("WelcomeUser.jsp?status=" + status1);
				}
			} else {
				response.sendRedirect("WelcomeUser.jsp?status=" + status);
			}

		} else if (!String.valueOf(request.getParameter("withdraw")).equalsIgnoreCase("")) {
			System.out.println("else condition");
			float withdraw = Float.parseFloat(request.getParameter("withdraw"));

			total_amt -= withdraw;

			userTrans.setUserId(userId);
			userTrans.setWithdraw(withdraw);
			userTrans.setTotal_amt(total_amt);
			userTrans.setDate(String.valueOf(date));

			userdetail.setBalance(total_amt);
			userdetail.setUserId(String.valueOf(userId));

			String status = userBalUpdate.updateUserBalance(userdetail);

			if (!status.equalsIgnoreCase("false")) {
				String status1 = userDto.addTransaction(userTrans);
				if (status1.equalsIgnoreCase("true")) {

//					---------------------------------------------------

					// Creating a result for getting status that messsage is delivered or not!
					String result;
					// Get recipient's email-ID, message & subject-line from index.html page
					final String to = "vikasjoshi19396@gmail.com";
					final String subject = "Bank Transactions";
					final String msg = "Dear Customer Mr/Ms " + userId
							+ ". Your Account Balance Has Been Updated with a Withdrawl of " + total_amt + " Rs.";

					// Sender's email ID and password needs to be mentioned
					final String from = "abc@gmail.com";
					final String pass = "abc@123";

					// Defining the gmail host
					String host = "smtp.gmail.com";

					// Creating Properties object
					Properties props = new Properties();

					// Defining properties
					props.put("mail.smtp.host", host);
					props.put("mail.transport.protocol", "smtp");
					props.put("mail.smtp.auth", "true");
					props.put("mail.smtp.starttls.enable", "true");
					props.put("mail.user", from);
					props.put("mail.password", pass);
					props.put("mail.smtp.port", "465");
					props.put("mail.debug", "true");
					props.put("mail.smtp.socketFactory.port", "465");
					props.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
					props.put("mail.smtp.socketFactory.fallback", "false");

					// Authorized the Session object.
					Session mailSession = Session.getInstance(props, new javax.mail.Authenticator() {
						@Override
						protected PasswordAuthentication getPasswordAuthentication() {
							return new PasswordAuthentication(from, pass);
						}
					});

					try {
						// Create a default MimeMessage object.
						MimeMessage message = new MimeMessage(mailSession);
						// Set From: header field of the header.
						message.setFrom(new InternetAddress(from));
						// Set To: header field of the header.
						message.addRecipient(Message.RecipientType.TO, new InternetAddress(to));
						// Set Subject: header field
						message.setSubject(subject);
						// Now set the actual message
						message.setText(msg);
						// Send message
						Transport.send(message);
						result = "true";
					} catch (MessagingException mex) {
						mex.printStackTrace();
						result = "false";
					}

//					----------------------------------------------------

					response.sendRedirect("WelcomeUser.jsp?status=" + result);
				} else {
					response.sendRedirect("WelcomeUser.jsp?status=" + status1);
				}
			} else {
				response.sendRedirect("WelcomeUser.jsp?status=" + status);
			}

		}

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
